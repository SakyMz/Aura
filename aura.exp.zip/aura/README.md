# AURA

Plataforma web responsiva de **segurança preventiva para mulheres**.

**Conceito:** transformar informação da comunidade em inteligência para decisões mais seguras.
**Posicionamento:** segurança preventiva. **Ideia central:** *"Informação antes da situação."*

## Como executar

Este é um aplicativo web 100% estático (HTML/CSS/JS). Não exige build.

1. Abra o arquivo `index.html` em qualquer navegador **OU** sirva a pasta com um servidor estático:
   ```
   python -m http.server 8080
   # depois acesse http://localhost:8080
   ```
2. Sem credenciais configuradas, o app roda em **MODO DEMONSTRAÇÃO** — os dados são claramente identificados como de demonstração (banner roxo no topo e dados mockados). Toda a interface, navegação e fluxos funcionam normalmente.

## Configurando o Firebase (produção)

1. Crie um projeto em https://console.firebase.google.com
2. Em **Authentication** → Sign-in method, habilite **E-mail/Senha**.
3. Em **Firestore Database**, crie o banco.
4. Em **Storage**, crie o bucket.
5. Em **Configurações do projeto** → **Seus apps** → **App Web**, copie o objeto `firebaseConfig`.
6. Cole o objeto em `js/config/firebase-config.js` (campos `apiKey`, `authDomain`, etc.).
7. Aplique as regras de segurança:
   - Firestore: conteúdo de `backend/rules/firestore.rules`
   - Storage: conteúdo de `backend/storage/storage.rules`

**Google Maps (opcional):**
- Obtenha uma chave API com a API *Maps JavaScript* habilitada em https://console.cloud.google.com
- Cole em `window.AURA_GOOGLE_MAPS_KEY` em `js/config/firebase-config.js`.
- Sem chave, o app usa um mapa de demonstração (Leaflet/OpenStreetMap). Nenhuma chave adicional é necessária.

## Estrutura do banco (Firestore)

### `users`
```
id, name, email, profileImage, createdAt, updatedAt
```
- **role**: para tornar uma usuária administradora, adicione o campo `role: "admin"` ao documento dela (manual no console) e aplique as regras `backend/rules/firestore.rules`.

### `reports`
```
id, userId, category, description, latitude, longitude,
riskLevel, date, createdAt, imageUrl, status, anonymous
```
- `status`: `pending` (em análise) | `published` | `closed` | `removed`
- `riskLevel`: `low` | `attention` | `moderate` | `high` | `critical`
- `anonymous`: relatos são anônimos por padrão

### `alerts`
```
id, title, description, latitude, longitude, riskLevel, createdAt, status
```

## Camadas do projeto

```
index.html                            Página única (SPA)
css/
  aura.css    Design system (tema roxo/lilás, botões, cards, risco, toast, modal)
  layout.css  Shell (sidebar, topbar, bottom-nav, marcadores)
  pages.css   Estilos das páginas
js/
  config/firebase-config.js            CREDENCIAIS (preencher)
  constants.js                         Categorias, níveis, status
  icons.js                             Iconografia SVG
  utils.js                             Datas, distância, sanitização
  services/
    data.js                            DataAccess (Firebase/Demo)
    map.js                             Google Maps + fallback Leaflet
  components/
    feedback.js                        Toast + Modal
    report-components.js               Cards e modal de detalhe de relato
  pages/
    landing.js  auth.js  home.js  map-page.js  report.js
    my-reports.js  profile.js  notifications.js  admin.js
  router.js                            Navegação + shell
  app.js                               Bootstrap
backend/
  rules/firestore.rules                Segurança do Firestore
  storage/storage.rules                Segurança do Storage
```

## Segurança e privacidade

- Autenticação via Firebase (usuário comum e admin, diferenciados pelo campo `role`).
- Regras do Firestore impedem que um usuário comum altere/exclua relatos de outros.
- Relatos são anônimos por padrão; o `userId` nunca é exibido publicamente.
- A localização informada em um relato é a do **local do ocorrido**, nunca a posição pessoal da usuária.
- As regras exigem validação dos dados enviados (status fixado em `pending` na criação).

## Inteligência de risco (arquitetura preparada)

O sistema está pronto para evoluir para um **índice de atenção da região** baseado em concentração, frequência, recência, categoria, gravidade, horário, reincidência e distância da usuária. A estrutura de notas/index fica em `js/constants.js` e é facilmente ajustável.

Futuro: 0–25 Baixo · 26–50 Atenção · 51–75 Moderado · 76–100 Alto.
